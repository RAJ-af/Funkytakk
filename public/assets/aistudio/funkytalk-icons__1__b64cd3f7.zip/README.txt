FunkyTalk icons

svg/      24x24 SVGs, use currentColor (stroke 2, round caps). Soft fill = 20% of the icon colour.
android/  VectorDrawable XML, drop into res/drawable/. Tinted by ?attr/colorControlNormal, so set app:tint / android:tint to recolour.
          *_filled.xml = solid version for active states (liked heart, saved bookmark, etc).
sprite.svg  all icons as <symbol id="i-name"> for web.
